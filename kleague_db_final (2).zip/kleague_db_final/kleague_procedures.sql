DROP PROCEDURE IF EXISTS sp_create_squad_battle;

DELIMITER $$

CREATE PROCEDURE sp_create_squad_battle(
    IN p_home_club_id INT,
    IN p_away_club_id INT
)
BEGIN
    DECLARE v_home_attack DECIMAL(6,2);
    DECLARE v_home_mid DECIMAL(6,2);
    DECLARE v_home_def DECIMAL(6,2);
    DECLARE v_home_gk DECIMAL(6,2);

    DECLARE v_away_attack DECIMAL(6,2);
    DECLARE v_away_mid DECIMAL(6,2);
    DECLARE v_away_def DECIMAL(6,2);
    DECLARE v_away_gk DECIMAL(6,2);

    DECLARE v_home_power DECIMAL(6,2);
    DECLARE v_away_power DECIMAL(6,2);

    DECLARE v_home_score INT;
    DECLARE v_away_score INT;

    DECLARE v_result VARCHAR(10);

    -- 홈팀 공격력
    SELECT AVG(ps.overall)
    INTO v_home_attack
    FROM players p
    JOIN player_stats ps ON p.player_id = ps.player_id
    WHERE p.club_id = p_home_club_id
      AND p.position_group = 'FW';

    -- 홈팀 미드
    SELECT AVG(ps.overall)
    INTO v_home_mid
    FROM players p
    JOIN player_stats ps ON p.player_id = ps.player_id
    WHERE p.club_id = p_home_club_id
      AND p.position_group = 'MF';

    -- 홈팀 수비
    SELECT AVG(ps.overall)
    INTO v_home_def
    FROM players p
    JOIN player_stats ps ON p.player_id = ps.player_id
    WHERE p.club_id = p_home_club_id
      AND p.position_group = 'DF';

    -- 홈팀 GK
    SELECT AVG(ps.overall)
    INTO v_home_gk
    FROM players p
    JOIN player_stats ps ON p.player_id = ps.player_id
    WHERE p.club_id = p_home_club_id
      AND p.position_group = 'GK';

    -- 원정팀 공격력
    SELECT AVG(ps.overall)
    INTO v_away_attack
    FROM players p
    JOIN player_stats ps ON p.player_id = ps.player_id
    WHERE p.club_id = p_away_club_id
      AND p.position_group = 'FW';

    -- 원정팀 미드
    SELECT AVG(ps.overall)
    INTO v_away_mid
    FROM players p
    JOIN player_stats ps ON p.player_id = ps.player_id
    WHERE p.club_id = p_away_club_id
      AND p.position_group = 'MF';

    -- 원정팀 수비
    SELECT AVG(ps.overall)
    INTO v_away_def
    FROM players p
    JOIN player_stats ps ON p.player_id = ps.player_id
    WHERE p.club_id = p_away_club_id
      AND p.position_group = 'DF';

    -- 원정팀 GK
    SELECT AVG(ps.overall)
    INTO v_away_gk
    FROM players p
    JOIN player_stats ps ON p.player_id = ps.player_id
    WHERE p.club_id = p_away_club_id
      AND p.position_group = 'GK';

    -- 최종 전투력 계산
    SET v_home_power =
        (v_home_attack * 1.4) +
        (v_home_mid * 1.2) +
        (v_home_def * 1.2) +
        (v_home_gk * 1.5) +
        (RAND() * 3);

    SET v_away_power =
        (v_away_attack * 1.4) +
        (v_away_mid * 1.2) +
        (v_away_def * 1.2) +
        (v_away_gk * 1.5) +
        (RAND() * 3);

    -- 스코어 생성
    SET v_home_score = FLOOR(v_home_power / 120);
    SET v_away_score = FLOOR(v_away_power / 120);

    -- 승패 판정
    IF v_home_score > v_away_score THEN
        SET v_result = 'home';
    ELSEIF v_home_score < v_away_score THEN
        SET v_result = 'away';
    ELSE
        SET v_result = 'draw';
    END IF;

    INSERT INTO squad_battles (
        home_club_id,
        away_club_id,
        home_score,
        away_score,
        home_power,
        away_power,
        result,
        battle_date
    )
    VALUES (
        p_home_club_id,
        p_away_club_id,
        v_home_score,
        v_away_score,
        v_home_power,
        v_away_power,
        v_result,
        CURDATE()
    );

    SELECT
        v_home_power AS home_power,
        v_away_power AS away_power,
        v_home_score AS home_score,
        v_away_score AS away_score,
        v_result AS result;

END $$

DELIMITER ;