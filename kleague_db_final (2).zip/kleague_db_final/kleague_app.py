import os
import pandas as pd
import pymysql
import streamlit as st
import streamlit.components.v1 as components


DB_CONFIG = {
    "host": "localhost",
    "port": 3306,
    "user": "root",
    "password": "1234",
    "database": "kleague_db",
    "charset": "utf8mb4",
    "cursorclass": pymysql.cursors.Cursor,
}

COLUMN_MAPPING = {
    "club_name": "구단명",
    "manager_name": "감독명",
    "preferred_formation": "선호 포메이션",
    "player_count": "선수 수",
    "avg_player_overall": "평균 오버롤",
    "manager_rating": "감독 능력치",
    "squad_score": "스쿼드 점수",
    "initial_budget_eur": "초기 예산 (EUR)",
    "current_budget_eur": "현재 예산 (EUR)",
    "total_spent_eur": "총 지출 (EUR)",
    "position_group": "포지션 그룹",
    "avg_overall": "평균 오버롤",
    "player_name": "선수명",
    "primary_position": "주포지션",
    "nationality": "국적",
    "market_value_eur": "시장 가치 (EUR)",
    "appearances": "출전 횟수",
    "goals": "득점",
    "assists": "도움",
    "overall": "오버롤",
    "seller_club": "판매 구단",
    "asking_fee_eur": "요구 이적료 (EUR)",
    "transfer_id": "이적 ID",
    "from_club": "이전 구단",
    "to_club": "이적 구단",
    "transfer_type": "이적 형태",
    "fee_eur": "이적료 (EUR)",
    "transfer_date": "이적일",
    "memo": "비고",
    "battle_id": "배틀 ID",
    "home_club": "홈 팀",
    "away_club": "원정 팀",
    "home_score": "홈 점수",
    "away_score": "원정 점수",
    "result": "결과",
    "battle_date": "경기일"
}


def get_conn():
    return pymysql.connect(**DB_CONFIG)


def run_query(sql, params=None):
    conn = get_conn()
    try:
        return pd.read_sql(sql, conn, params=params)
    finally:
        conn.close()


def run_procedure(sql, params=None):
    conn = get_conn()
    try:
        with conn.cursor() as cur:
            cur.execute(sql, params or [])
            conn.commit()
            if cur.description:
                columns = [item[0] for item in cur.description]
                return pd.DataFrame(cur.fetchall(), columns=columns), None
            return pd.DataFrame(), None
    except Exception as exc:
        conn.rollback()
        
        error_msg = str(exc)
        if "chk_contract_dates" in error_msg:
            error_msg = "계약 기간 데이터 오류"
        elif "Duplicate entry" in error_msg:
            error_msg = "중복 데이터 오류"
        elif "foreign key constraint fails" in error_msg.lower():
            error_msg = "데이터 연결 오류"
            
        return pd.DataFrame(), error_msg
    finally:
        conn.close()


st.set_page_config(
    page_title="K리그 이적시장 시뮬레이터",
    page_icon="⚽",
    layout="wide"
)

st.title("K리그 이적시장 시뮬레이터")

users_df = run_query("""
    SELECT u.user_id,
           u.username,
           c.club_id,
           c.club_name,
           c.current_budget_eur
    FROM app_users u
    JOIN clubs c
        ON u.club_id = c.club_id
    ORDER BY c.club_name
""")

if users_df.empty:
    st.error("사용자를 찾을 수 없습니다. 먼저 SQL 파일을 실행하세요.")
    st.stop()

display_name_map = {
    "manager_fc_seoul": "FC 서울 감독",
    "manager_ulsan_hd_fc": "울산 HD 감독",
    "manager_jeonbuk_hyundai_motors": "전북 현대 감독",
    "manager_gangwon_fc": "강원 FC 감독",
    "manager_pohang_steelers": "포항 스틸러스 감독",
    "manager_incheon_united": "인천 유나이티드 감독",
    "manager_fc_anyang": "FC 안양 감독",
    "manager_jeju_sk": "제주 SK 감독",
    "manager_bucheon_fc_1995": "부천 FC 1995 감독",
    "manager_daejeon_hana_citizen": "대전 하나 시티즌 감독",
    "manager_gimcheon_sangmu": "김천 상무 감독",
    "manager_gwangju_fc": "광주 FC 감독"
}

users_df["display_name"] = users_df["username"].map(display_name_map)

user_options = {
    f"{row.display_name} / {row.club_name}": int(row.user_id)
    for row in users_df.itertuples()
}

selected_user_label = st.sidebar.selectbox(
    "사용자 / 구단 선택",
    list(user_options.keys())
)

selected_user_id = user_options[selected_user_label]

my_row = users_df[users_df["user_id"] == selected_user_id].iloc[0]

my_club_id = int(my_row["club_id"])
my_club_name = my_row["club_name"]
my_budget = float(my_row["current_budget_eur"])

st.sidebar.metric("선택된 구단", my_club_name)
st.sidebar.metric("현재 예산 (EUR)", f"{my_budget:,.0f}")

page = st.sidebar.radio(
    "메뉴",
    ["대시보드", "내 스쿼드", "이적 시장", "스쿼드 배틀", "기록"]
)

st.sidebar.markdown("---")

if st.sidebar.button("시뮬레이션 초기화"):
    conn = get_conn()
    cur = conn.cursor()

    # 1. 기존 거래소 초기화
    cur.execute("DELETE FROM transfer_market")

    # 2. 선수 소속 원상복구 (이게 먼저 와야 함)
    cur.execute("""
        UPDATE players
        SET club_id = original_club_id
        WHERE player_id > 0
    """)

    # 3. 예산 및 포메이션 초기화
    cur.execute("""
        UPDATE clubs
        SET current_budget_eur = initial_budget_eur,
            total_spent_eur = 0,
            formation = '4-3-3'
        WHERE club_id > 0
    """)

    # 4. 배틀 / 이적 기록 초기화
    cur.execute("DELETE FROM transfer_history")
    cur.execute("DELETE FROM squad_battles")

    # 5. 거래소 재생성
    cur.execute("""
        INSERT INTO transfer_market
        (listing_id, player_id, seller_club_id, asking_fee_eur, listed_date, status)

        SELECT
            ROW_NUMBER() OVER (ORDER BY ps.overall DESC),
            p.player_id,
            p.club_id,
            p.market_value_eur,
            CURDATE(),
            'available'
        FROM players p
        JOIN player_stats ps
             ON p.player_id = ps.player_id
       WHERE ps.overall >= 75
    """)

    conn.commit()
    cur.close()
    conn.close()

    st.sidebar.success("초기화 완료!")
    st.rerun()

if page == "대시보드":
    col1, col2 = st.columns(2)

    with col1:
        st.subheader("스쿼드 점수 랭킹")
        st.dataframe(
            run_query("""
                SELECT club_name,
                       manager_name,
                       preferred_formation,
                       player_count,
                       avg_player_overall,
                       manager_rating,
                       squad_score
                FROM v_squad_score
                ORDER BY squad_score DESC
            """),
            use_container_width=True,
            hide_index=True,
            column_config=COLUMN_MAPPING
        )

    with col2:
        st.subheader("구단별 예산 현황")
        st.dataframe(
            run_query("""
                SELECT club_name,
                       initial_budget_eur,
                       current_budget_eur,
                       total_spent_eur
                FROM v_club_budget
                ORDER BY current_budget_eur DESC
            """),
            use_container_width=True,
            hide_index=True,
            column_config=COLUMN_MAPPING
        )

    st.subheader("포지션별 뎁스")
    st.dataframe(
        run_query("""
            SELECT club_name,
                   position_group,
                   player_count,
                   avg_overall
            FROM v_position_depth
            ORDER BY club_name,
                     FIELD(position_group, 'GK', 'DF', 'MF', 'FW')
        """),
        use_container_width=True,
        hide_index=True,
        column_config=COLUMN_MAPPING
    )

elif page == "내 스쿼드":
    st.subheader(f"{my_club_name} 스쿼드 현황 (조회 전용)")
    
    # --- [복구/추가] 1단계: 포메이션 설정 UI 제공 ---
    st.subheader("포메이션 설정")

    formation_options = [
        "4-3-3",
        "4-4-2",
        "4-2-3-1",
        "3-5-2"
    ]

    current_formation_df = run_query("""
        SELECT formation
        FROM clubs
        WHERE club_id = %s
    """, (my_club_id,))

    current_formation = current_formation_df.iloc[0]["formation"]

    selected_formation = st.selectbox(
        "포메이션 선택",
        formation_options,
        index=formation_options.index(current_formation)
    )

    if st.button("포메이션 저장"):
        conn = get_conn()
        try:
            with conn.cursor() as cur:
                cur.execute("""
                    UPDATE clubs
                    SET formation = %s
                    WHERE club_id = %s
                """, (
                    selected_formation,
                    my_club_id
                ))
            conn.commit()
            st.success("포메이션 저장 완료!")
            st.rerun()
        finally:
            conn.close()

    squad_df = run_query("""
        SELECT player_id,
               player_name,
               position_group,
               primary_position,
               nationality,
               market_value_eur,
               appearances,
               goals,
               assists,
               overall
        FROM v_player_info
        WHERE club_name = %s
        ORDER BY FIELD(position_group, 'GK', 'DF', 'MF', 'FW'),
                 overall DESC
    """, (my_club_name,))

    current_squad_count = len(squad_df)

    if current_squad_count < 11:
        st.warning(f"현재 스쿼드 인원이 부족합니다 ({current_squad_count}/11)")

    st.dataframe(
        squad_df.drop(columns=["player_id"]),
        use_container_width=True,
        hide_index=True,
        column_config=COLUMN_MAPPING
    )

    st.markdown("---")

    # --- [복구/추가] 3단계 & 4단계: 현재 포메이션 동적 동기화 및 X/Y축 변환부 정의 ---
    formation_db_df = run_query("""
        SELECT formation
        FROM clubs
        WHERE club_id = %s
    """, (my_club_id,))

    formation_current = formation_db_df.iloc[0]["formation"]

    st.subheader(f"전술 배치도 ({formation_current})")

    pitch_html = (
        '<div style="position:relative; width:700px; height:900px; background:#0b6623; '
        'border:4px solid white; margin:auto; border-radius:10px; overflow:hidden;">'
        '<div style="position:absolute; left:0; top:50%; width:100%; height:2px; background:white;"></div>'
        '<div style="position:absolute; top:50%; left:50%; transform:translate(-50%,-50%); '
        'width:120px; height:120px; border:2px solid white; border-radius:50%;"></div>'
    )

    position_df = run_query("""
        SELECT
            sp.player_id,
            sp.pos_x,
            sp.pos_y,
            p.player_name,
            ps.overall
        FROM squad_positions sp
        JOIN players p
            ON sp.player_id = p.player_id
        JOIN player_stats ps
            ON p.player_id = ps.player_id
        WHERE sp.club_id = %s
    """, (my_club_id,))

    # [수정 가동 및 정렬] 루프 교체 코드 블록 진입
    fw_players = []
    mf_players = []
    df_players = []
    gk_players = []

    for _, row in position_df.iterrows():
        player_id = row["player_id"]

        position_group_df = run_query("""
            SELECT position_group
            FROM players
            WHERE player_id = %s
        """, (player_id,))

        position_group = position_group_df.iloc[0]["position_group"]

        if position_group == "FW":
            fw_players.append(row)
        elif position_group == "MF":
            mf_players.append(row)
        elif position_group == "DF":
            df_players.append(row)
        else:
            gk_players.append(row)

    # 포메이션별 전술적 격자 좌표망 확정 (X축 가변화 구현)
    if formation_current == "4-3-3":
        fw_x = [25, 50, 75]
        mf_x = [30, 50, 70]
        df_x = [20, 40, 60, 80]
    elif formation_current == "4-4-2":
        fw_x = [40, 60]
        mf_x = [20, 40, 60, 80]
        df_x = [20, 40, 60, 80]
    elif formation_current == "4-2-3-1":
        fw_x = [50]
        mf_x = [25, 50, 75, 90]
        df_x = [20, 40, 60, 80]
    else:  # 3-5-2
        fw_x = [40, 60]
        mf_x = [15, 35, 50, 65, 85]
        df_x = [30, 50, 70]

    # 글로벌 변수 연동 기반 동적 그리기 렌더러 함수
    def draw_players(players, x_positions, y_pos):
        global pitch_html
        for idx, row in enumerate(players):
            if idx >= len(x_positions):
                break
            
            x = x_positions[idx]
            player_name = row["player_name"]
            overall = row["overall"]

            pitch_html += (
                f'<div style="position:absolute; left:{x}%; top:{y_pos}%; '
                f'transform:translate(-50%,-50%); '
                f'background:#111827; color:white; padding:8px; '
                f'border-radius:10px; width:95px; text-align:center; '
                f'font-size:12px; border:2px solid gold;">'
                f'<b>{player_name}</b><br>OVR {overall}</div>'
            )

    # 각 포지션 그룹별 정밀 스크린 프린팅 실행
    draw_players(fw_players, fw_x, 20)
    draw_players(mf_players, mf_x, 45)
    draw_players(df_players, df_x, 72)
    draw_players(gk_players, [50], 88)

    pitch_html += "</div>"
    components.html(pitch_html, height=950)

elif page == "이적 시장":
    st.subheader("영입 가능한 선수 목록 (거래소)")

    filter_col1, filter_col2 = st.columns(2)
    with filter_col1:
        position_filter = st.selectbox("포지션 필터", ["전체", "GK", "DF", "MF", "FW"])
    with filter_col2:
        search_name = st.text_input("선수 이름 검색")

    market_df = run_query("""
        SELECT listing_id,
               player_name,
               position_group,
               primary_position,
               nationality,
               overall,
               seller_club,
               asking_fee_eur,
               seller_club_id
        FROM v_transfer_market
        WHERE seller_club_id <> %s
        ORDER BY overall DESC, asking_fee_eur DESC
    """, (my_club_id,))

    if position_filter != "전체":
        market_df = market_df[market_df["position_group"] == position_filter]

    if search_name:
        market_df = market_df[market_df["player_name"].str.contains(search_name, case=False)]

    st.dataframe(
        market_df.drop(columns=["listing_id", "seller_club_id"]),
        use_container_width=True,
        hide_index=True,
        column_config=COLUMN_MAPPING
    )

    st.markdown("---")
    st.subheader("즉시 스쿼드 트레이드 (동일 포지션 제한)")

    if not market_df.empty:
        market_df["display_key"] = market_df.apply(
            lambda r: f"{r['player_name']} | {r['position_group']} | OVR {r['overall']} | {r['seller_club']} | 요구액: EUR {r['asking_fee_eur']:,.0f}", axis=1
        )

        buy_options = list(market_df["display_key"])
        selected_buy_key = st.selectbox("1. 영입할 타 팀 선수 선택", buy_options, key="trade_buy_selector")

        selected_buy_row = market_df[market_df["display_key"] == selected_buy_key].iloc[0]
        target_position = selected_buy_row["position_group"]
        buy_price = float(selected_buy_row["asking_fee_eur"])
        selected_listing_id = int(selected_buy_row["listing_id"])

        my_squad_raw = run_query("""
            SELECT player_id,
                   player_name,
                   position_group,
                   market_value_eur,
                   overall
            FROM v_player_info
            WHERE club_name = %s
            ORDER BY overall DESC
        """, (my_club_name,))

        same_position_df = my_squad_raw[my_squad_raw["position_group"] == target_position].copy()

        if not same_position_df.empty:
            same_position_df["display_key"] = same_position_df.apply(
                lambda r: f"{r['player_name']} | {r['position_group']} | OVR {r['overall']} | 내 구단 가치: EUR {r['market_value_eur']:,.0f}", axis=1
            )

            sell_options = list(same_position_df["display_key"])
            
            selected_sell_key = st.selectbox(
                f"2. 보낼 내 선수 선택 ({target_position} 포지션 자동 제한됨)", 
                sell_options, 
                key="trade_sell_selector"
            )

            selected_sell_row = same_position_df[same_position_df["display_key"] == selected_sell_key].iloc[0]
            sell_price = float(selected_sell_row["market_value_eur"])
            selected_my_player_id = int(selected_sell_row["player_id"])

            net_cost = buy_price - sell_price

            st.info(f"""
            **💰 이적 거래 정산서**
            * 영입 대상 선수 비용: **EUR {buy_price:,.0f}**
            * 내 방출 선수 트레이드 금액: **EUR {sell_price:,.0f}**
            * ────────────────────────
            * 📢 **최종 정산 차액: EUR {net_cost:,.0f}** *(양수일 때 내 예산 감소 / 음수일 때 내 예산 보너스 추가)*
            """)

            if st.button("즉시 트레이드 실행", type="primary"):
                result, err = run_procedure(
                    "CALL sp_trade_players(%s, %s, %s, %s)",
                    (selected_user_id, selected_listing_id, selected_my_player_id, net_cost)
                )

                if err:
                    st.error(err)
                else:
                    st.success("🤝 트레이드 완료! 양 팀 선수의 구단 소속 변경 및 예산 정산이 즉시 성사되었습니다.")
                    st.rerun()
        else:
            st.warning(f"내 스쿼드에 상대방 영입 포지션인 ({target_position}) 그룹에 속한 선수가 단 한 명도 없어 트레이드를 진행할 수 없습니다.")
    else:
        st.warning("현재 이적시장에 등록되어 트레이드 가능한 타 구단 매물이 없습니다.")

elif page == "스쿼드 배틀":
    st.subheader("스쿼드 배틀 생성")

    clubs_df = run_query("""
        SELECT club_id, club_name
        FROM clubs
        WHERE club_id <> %s
        ORDER BY club_name
    """, (my_club_id,))

    opponents = {row.club_name: int(row.club_id) for row in clubs_df.itertuples()}
    selected_opp = st.selectbox("상대 구단 선택", list(opponents.keys()))

    home_squad_count = run_query("""
        SELECT COUNT(*) AS cnt
        FROM players
        WHERE club_id = %s
    """, (my_club_id,)).iloc[0]["cnt"]

    if home_squad_count < 11:
        st.error("스쿼드 인원이 부족하여 배틀이 불가능합니다.")
    else:
        if st.button("배틀 시작", type="primary"):
            result, err = run_procedure(
                "CALL sp_create_squad_battle(%s, %s)",
                (my_club_id, opponents[selected_opp])
            )

            if err:
                st.error(err)
            # --- [복구 완료] 1단계: 잃어버린 스쿼드 배틀 카드 커스텀 UI 및 로직 완벽 복원 ---
            else:
                row = result.iloc[0]

                home_power = float(row["home_power"])
                away_power = float(row["away_power"])

                home_score = int(row["home_score"])
                away_score = int(row["away_score"])

                result_text = row["result"]

                if result_text == "home":
                    result_label = "🏆 Home Win"
                    border_color = "#00ff88"
                elif result_text == "away":
                    result_label = "🔥 Away Win"
                    border_color = "#ff4b4b"
                else:
                    result_label = "🤝 Draw"
                    border_color = "#ffd700"

                total_power = home_power + away_power
                home_possession = round((home_power / total_power) * 100)
                away_possession = 100 - home_possession

                home_shots = max(1, int(home_power / 25))
                away_shots = max(1, int(away_power / 25))

                st.success("⚽ 스쿼드 배틀 완료!")

                st.markdown(f"""
                <div style="
                    background:#08142b;
                    padding:40px;
                    border-radius:20px;
                    border:3px solid {border_color};
                    text-align:center;
                    color:white;
                    margin-top:20px;
                ">
                <h1>{my_club_name} {home_score} : {away_score} {selected_opp}</h1>
                <h2 style="color:{border_color};">{result_label}</h2>
                <hr style="border:1px solid #374151;">
                <h3>🔥 홈팀 전투력: {home_power:.1f}</h3>
                <h3>🛡️ 원정팀 전투력: {away_power:.1f}</h3>
                </div>
                """, unsafe_allow_html=True)

                col1, col2 = st.columns(2)
                with col1:
                    st.metric(f"{my_club_name} 점유율", f"{home_possession}%")
                    st.metric(f"{my_club_name} 유효슈팅", home_shots)
                with col2:
                    st.metric(f"{selected_opp} 점유율", f"{away_possession}%")
                    st.metric(f"{selected_opp} 유효슈팅", away_shots)
            # --------------------------------------------------------------------------

elif page == "기록":
    st.subheader("이적 히스토리")
    st.dataframe(
        run_query("""
            SELECT th.transfer_id,
                   p.player_name,
                   fc.club_name AS from_club,
                   tc.club_name AS to_club,
                   th.transfer_type,
                   th.fee_eur,
                   th.transfer_date,
                   th.memo
            FROM transfer_history th
            JOIN players p ON th.player_id = p.player_id
            LEFT JOIN clubs fc ON th.from_club_id = fc.club_id
            LEFT JOIN clubs tc ON th.to_club_id = tc.club_id
            ORDER BY th.transfer_id DESC
        """),
        use_container_width=True,
        hide_index=True,
        column_config=COLUMN_MAPPING
    )

    st.subheader("스쿼드 배틀 매치 히스토리")
    # --- [복구 완료] 2단계: 히스토리 테이블 내 result의 가시성을 위해 CASE WHEN 구문 삽입 ---
    st.dataframe(
        run_query("""
            SELECT sb.battle_id,
                   hc.club_name AS home_club,
                   ac.club_name AS away_club,
                   sb.home_score,
                   sb.away_score,
                   CASE 
                       WHEN sb.result = 'home' THEN 'Home Win'
                       WHEN sb.result = 'away' THEN 'Away Win'
                       ELSE 'Draw'
                   END AS result,
                   sb.battle_date
            FROM squad_battles sb
            JOIN clubs hc ON sb.home_club_id = hc.club_id
            JOIN clubs ac ON sb.away_club_id = ac.club_id
            ORDER BY sb.battle_id DESC
        """),
        use_container_width=True,
        hide_index=True,
        column_config=COLUMN_MAPPING
    )